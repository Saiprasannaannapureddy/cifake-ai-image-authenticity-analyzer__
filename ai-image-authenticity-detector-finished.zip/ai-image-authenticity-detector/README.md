# AI Image Authenticity Detector

A CNN-based web application that classifies an image as **REAL** or **AI-GENERATED** using the CIFAKE dataset.

## Project idea

Generative AI can create realistic images that are difficult to identify manually. This project uses a Convolutional Neural Network (CNN) to learn visual patterns from real and synthetic images and provide a binary prediction through a Flask web interface.

> This is an educational/research prototype. A model prediction is not proof of image authenticity.

## Main features

- CNN-based binary image classification
- Flask web interface
- Image preview before upload
- Supported JPG, JPEG, PNG and WEBP images
- 5 MB upload limit
- Secure, generated filenames for uploaded images
- Confidence percentage with a visual confidence bar
- Reusable image preprocessing and prediction module
- Training callbacks for early stopping, learning-rate reduction and best-model saving

## Technology stack

- Python
- TensorFlow / Keras
- CNN
- Flask
- Pillow
- NumPy
- OpenCV

## Dataset

The project is designed for the **CIFAKE** dataset. The dataset itself is not included in this repository because of its size and licensing/distribution considerations.

Expected local structure:

```text
dataset/
├── train/
│   ├── FAKE/
│   └── REAL/
└── test/
    ├── FAKE/
    └── REAL/
```

## Repository structure

```text
ai-image-authenticity-detector/
├── app.py
├── predict.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── dataset/
│   └── README.md
├── models/
│   └── image_detector.keras
├── static/
│   └── uploads/
│       └── .gitkeep
└── templates/
    ├── index.html
    └── result.html
```

## Setup on Windows

### 1. Create a virtual environment

```bash
python -m venv venv
```

Activate it:

```bash
venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Add the dataset

Place the CIFAKE data under the `dataset/` folder using the structure shown above.

### 4. Train the model

```bash
python train_model.py
```

The best model is saved to:

```text
models/image_detector.keras
```

### 5. Start the web application

```bash
python app.py
```

Open the local Flask address shown in the terminal.

## Using the application

1. Open the web page.
2. Select an image.
3. Preview the selected image.
4. Click **Analyze Image**.
5. The application displays:
   - predicted class
   - confidence percentage
   - uploaded image

## Implementation improvements

Compared with a basic single-file implementation, this version separates inference into `predict.py`, validates upload types and file size, generates unique upload names, reuses the loaded model, and uses training callbacks to save the best checkpoint and adjust the learning rate when validation loss stops improving.

## Limitations

- Performance depends on the training data and model.
- The detector may fail on image types that differ from the training distribution.
- Confidence is a model score, not a guaranteed probability of authenticity.
- The current model is a CNN baseline and can be improved with transfer learning and explainability methods.

## Future work

- Grad-CAM visual explanations
- Transfer-learning models such as EfficientNet
- More synthetic-image datasets
- Confusion matrix and per-class evaluation
- Better confidence calibration
- API endpoint for programmatic predictions
- Experiment tracking and model comparison

## Project purpose

This repository is intended for learning, internship practice, and research experimentation in computer vision and synthetic-image detection.
